#lambda-- it is small and nameless or anonymous function
'''
#if we dont have any name we can assign that anonyomous function with an object using that object we can access the function
add = lambda a:a+10
print(add(50))


#using multiple parameters

y = lambda a,b:a-b
print(y(93256,657893))

#using a lamda function inside of a normal function

def func(para):
    return  lambda a:a*para

obj = func(56)
print(obj(4))
obj1 = func(45)
print(obj(7))


#filter -- used filter particular values based on given conditions

l1 = [34,65,78,9,0,11,23,44]
re = list(filter(lambda x: x%2 != 0,l1))
print(re)

#map -- using map we can apply some operation to all elements which is available in the sequence
l1 = [34,65,78,9,0,11,23,44]

re = list(map(lambda x:x*2,l1))
print(re)
'''

#reduce -- it will by doing some operation it will turn all the sequence elements into a single value

from  functools import reduce

l1 = [34,65,78,9,0,11,23,44]
re = reduce(lambda x,y:x+y,l1)
print(re)
