#a loop used to go through or iterate over a sequence -- for loop
#
'''
a = (23,45,76,89)

for i in a:#fetch each elements and print them into next lines

    print(i)


#if case inside of for loop
a = (23, 45, 76, 89)

for i in a:
  if i%2 == 0:
    print(i)


#break operation inside of for loop:

fruits = ['kiwi','lemon','cherry','guaua','orange']

for fruit in fruits:
    if fruit == 'guaua':
        break
    print(fruit)


#continue operation inside of for loop:

fruits = ['kiwi','lemon','cherry','guaua','orange']

for fruit in fruits:
    if fruit == 'guaua':
        continue
    print(fruit)

#else with for loop-- when the for loop get closes then else case will execute

fruits = ['kiwi','lemon','cherry','guaua','orange']

for fruit in fruits:
    print(fruit)
else:
    print('end of the loop')







# a loop inside of a loop is a nested loop
fruits = ['apple','orange','kiwi','grapes']
colors = ['red','green','yellow']

for i in fruits:
    for j in colors:
        print('the fruit color is {} and the fruit name is {}'.format(i,j))




for  i in range(10):
    for j in range(10-i,10+i):
        print('$',end='')

    print()

'''

for i in range(12):
    if i ==11:
        print('helloworld')
    else:
        print(i)
