
#creating , reading ,writing, updating, deleting
#open() --if you want work with a file use 'open()' to get access to handle the file
#open() will take two parameters first one is the file name second one is the mode open operation

#'w'--used to create a new file and if the file already it will remove all the existing data from that file and enter the
#new given files if it is not exist it will create new file
'''
f = open('hello.txt','w')
f.write('good morning \n the day name today is thursday')
f.close()
#r- it is a immutable status mode which we are not able to change the file's existing data just we can read it

f = open('hello.txt','r')
#print(f.read())
print(f.readline())
print(f.readline())
f.close()

#'a' - append will not erase the existing data in a file but it will add more datas in that file

f = open('hello.txt','a')
f.write('\n this line added by append mode')

#'x' -- to check a file already exists or not before creating a file with a same name

f = open('hellos.txt','x')

#with statement -- what code that we are writing for that file will open out of the it will get close:

with open('hello.txt','r') as f:
    print(f.readline())

#print(f.read())#I/O operation on closed file.

f = open('hello.txt','r')
print(f.tell())
f.seek(7)
print(f.tell())
print(f.read())



f = open('kailash.jpg','rb')
f1 = open('newPic.jpg','wb')
data = f.read()
f1.write(data)

'''
import csv

with open('category.csv','r') as f:
    file = csv.reader(f)

    for i in file:
        print(i)

        with open('stores.csv','a') as d:
            data = csv.writer(d)
            data.writerow(i)
