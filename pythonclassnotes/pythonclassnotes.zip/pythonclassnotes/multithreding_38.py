#thread -- it is a subset  of the process. a process can have multithreds
'''
#if we put two threads it will crash with each other
import threading
import time

def hello_five():
    for i in range(5):
        print('hello',i)


def hi_five():
    for i in range(5):
        print('say hi',i)

t1 =threading.Thread(target=hello_five)
t2 =threading.Thread(target=hi_five)

t1.start()
t2.start()
'''


import threading
import time

def hello_five():
    for i in range(5):
        print('hello',i)
        time.sleep(1)

def hi_five():
    for i in range(5):
        print('say hi',i)
        time.sleep(1.1)

t1 =threading.Thread(target=hello_five)
t2 =threading.Thread(target=hi_five)

t1.start()
t2.start()
