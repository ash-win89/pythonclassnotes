
#iteration-a process that is repeated more than one time by applying the same logic is called an iteration
#iterator--an iterator is an object  which contains a countable number of values and it is used to iterate over
#iterable objects-string,list,tuple,set

#iter() --keyword used to create an iterator containing an iterable object
#next() -- keyword used to call the next element in the iterable object
# through all the values
'''
l = [5,2,8,5,7,9]
it = iter(l)

print(next(it))
print(next(it))
print(next(it))
print(next(it))

a = 'apple'

for i in a:
    print(i)



class Numbers:
    #__iter__ function returns an iterator for the initialized object(set,tuple)creates an object that can
    #be accessed one element at a time
    def __iter__(self):
        self.a =1
        return self

    #the __next__ function can be accessed through next keyword
    def __next__(self):

        x =self.a
        self.a +=1
        return x

n = Numbers()
it = iter(n)

print(next(it))
print(next(it))
print(next(it))
print(next(it))
print(next(it))


class Numbers:

    def __iter__(self):
        self.a = 1
        return self

    def __next__(self):
       if self.a <=8:
            x = self.a
            self.a += 1
            return x
       else:
           raise StopIteration


n = Numbers()
it = iter(n)

# for i in it:
#     print(i)

print(next(it))
print(next(it))
print(next(it))
print(next(it))
print(next(it))
print(next(it))
print(next(it))
print(next(it))
print(next(it))
print(next(it))


'''
#generators-- a generator it is just like normal function whenever it needs generate next we have yield to generate them
#or
#generators function is same as normal fucntion but when it needs to generate a value it will do with 'yield'
def num():
    yield 1
    yield 2
    yield 6

t =num()
print(t.__next__())
print(t.__next__())
print(t.__next__())
print(t.__next__())
