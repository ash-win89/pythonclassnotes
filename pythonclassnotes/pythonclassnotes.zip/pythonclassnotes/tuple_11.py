#tuple datastructure --exactly same as list data type except that it is immutable

a = (4,7,1)
#a[0] = 98 # this will throw you error

#and it will not support any append(), remove(),

#addition operations
b= (7,6,2,'apple')
c = a+b
print(c)


d = a*2
print(d)

#len and count
print(len(b))
print(b.count(2))

#sorting and reversing

#e = b.reverse()
#e = b.sort()
print(b[1])
print(b[0:2])
