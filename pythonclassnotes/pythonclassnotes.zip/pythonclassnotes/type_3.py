#to find what kind of data type we can use type keyword

a =3
b=0b01
c = 0o654
d= 0x98ad
e='hello world' #string is a sequence
f = True
g = 5+7j
i = None
j = 8.976523

#type keyword will return that given data types falls under which category
print(type(a))
print(type(b))
print(type(c))
print(type(d))
print(type(e))
print(type(f))
print(type(g))
print(type(i))
print(type(j))