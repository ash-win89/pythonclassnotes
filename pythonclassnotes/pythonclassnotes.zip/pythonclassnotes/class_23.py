
#pyton is based on oops in python everything is an object each objects has its properties and methods
#even class also object constructor or else we can say its a blueprint of a program
#to create a class we can 'class' keyword then we can define name following that keyword
'''
class hello:
     x=5

#print(hello.x)
#creating an object
h1 =hello()
print(h1.x)


#__init__()--a function which always executes when the class being initiated or called,this function used to
#assign values object properties
#constructor -- a constructor always executes when the class called

class const:


    def __init__(self,name,sal):
        self.name = name
        self.sal = sal
        #print('this is a constructor')


c = const('rdj',9000)
print(c.name)
print(c.sal)

#instance methods --an object can contain methods. object methods are functions that belong to the object
#self -- parameter is a reference to the current instance of the class. we can use it to access the variables
#which are belongs to the class
class const:


    def __init__(self,name,sal):
        self.name = name
        self.sal = sal

    def names(self):
        print('the user name is',self.name)

    def salary(self):
        print('the salary gettting paid',self.sal)

ob = const('robert',8000)
ob.names()
ob.salary()

#instead of giving self we can use any names

class const:


    def __init__(mine,name,sal):
        mine.name = name
        mine.sal = sal

    def names(other):
        print('the user name is',other.name)

    def salary(red):
        print('the salary gettting paid',red.sal)

ob = const('robert',8000)
ob.names()
ob.salary()

#modifying the object properties
ob1 =const('ryan',3000)
ob1.sal=5000
ob1.salary()
#deleting an object properties
del ob1.name
ob1.names()

class hello:
    pass

#instance methods--instance attributes not related by objects what we are creating based on classes a method which
#using initializers variables using self every objecs has its own copy instance attribute


#modifying initiated instance variables
class const:

    x=46
    def __init__(self,name,sal):
        self.name = name
        self.sal = sal


    def modifyName(self,NewName):
        self.name = NewName
        print(self.name)
    def modifysalary(self,Newsalary):
        self.sal = Newsalary
        print(self.sal)
a = const('chris',4000)
print(a.name)
print(a.sal)
a.modifyName('gary')
a.modifysalary(2000)





#static method -- a method is bound to a class rather than the objects for that class or
#static methods does rely on intializer variables it is a stanalone method

class state:
    def __init__(self, name, sal):
        self.name = name
        self.sal = sal

    @staticmethod
    def add(x,y):
        print(x-y)

s =state(5,4)

s.add(999,777)

#classmethod -- even classmethod also bound to the class not for its objects or
#class method used to access the values which is available inside of a class but which not inside of any methods
#using 'cls' keyword

class const:

    x=46
    def __init__(self,name,sal):
        self.name = name
        self.sal = sal

    @classmethod
    def add(cls,y):
        print(cls.x+y)

cl = const(45,23)
cl.add(888)

'''
class const:

    x=46
    def __init__(self,name,sal):
        self.name = name
        self.sal = sal
        print('this is a constructor')

    def names(self):
        print('the user name is',self.name)

    def salary(self):
        print('the salary gettting paid',self.sal)

    def detail(self):
        print('name of the person {} and the salary {}'.format(self.name,self.sal))

    @staticmethod
    def add():
        print('hello world')

    @classmethod
    def sub(cls,a):
        print(cls.x-a)

a =const('rdj','8000')
a.names()
a.salary()
a.detail()
a.add()
a.sub(20)
