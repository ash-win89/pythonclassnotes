#data structures--there are five types of data structures are there list, tuple, dictionary,set,range
#byte arrays also there

#list--If we want to represent a group of individual objects as a single entity where insertion order preserved and duplicates are allowed, then we should go for List.
#insertion order preserved.,heterogeneous objects are allowed.

l = [] #creating empty list
print(type(l))
#we can create list with elements

l = [45,34,23,98,76,True,'helloworld']
print(l)
#using list keyword

a = list(range(2,34))
print(a)

#converting a string into a list it will split each letter as a element

a = 'hello world'
l = list(a)
print(l)

#using split operation against a string to use to break on white space

b = 'hello everyone how are you'
l = b.split()
print(l)


#nested lists -- a list inside of another list
c = [30,20,50,[4,2,8]]
print(c[3][2])  #way of accessing nested elements
#normally using indexing  we can access all the elements in list
print(c[2])


#using slice operator
n = [18,16,14,12,10,8,6,4,2,6]
print(n[2:8:2])  #accessing based on steps
print(n[3:9])
print(n[1:100]) #end boundary out of range it will give till end


#we can modify the list content based on indexing
n = [18,16,14,12,10,8,6,4,2,6]
n[4] = 99
print(n)

#we can traverse through a sequence using loops

#for i in n:
    #print(i +2)


#important functions of list:

n = [18,16,14,12,10,8,6,4,2,6]
#len()-- used to find the how many values are there in that list
print(len(n))

#count() --It returns the number of occurrences of specified item in the list
print(n.count(6))

#index() -- returns the index of first occurrence of the specified item.

print(n.index(12))

#we can use membership operators
print(4 in n)

#manipulating list:

#append() --to add item at the end of the list.

l = [1,4,7]
l.append(9)
print(l)

#insert() --To insert item at specified index position

l.insert(1,33)#the 1 is position and 3 is the value
print(l)
#if you give out of range the value will  be added into end of the list
l.insert(100,4)
print(l)

#extend() --To add all items of one list to another list
l1 = [55,44]
l1.extend(l)
print(l1)

#remove()--to remove specified item from the list.If the item present
#multiple times then only first occurrence will be removed.
l1.remove(44)
print(l1)

#pop()--It removes and returns the last element of the list.

a =[4,2,9,6,7]
a.pop()
print(a)

#ordering elements of list

a =[4,2,9,6,7]
#reverse()--to reverse() order of elements of list.
a.reverse()
print(a)


#sort() --For numbers ==>default natural sorting order is Ascending Order
#For Strings ==> default natural sorting order is Alphabetical Order

a.sort()
print(a)



#if it is hetrogeneous we will get error

#aliasing and cloning will affect to the original

x = [7,3,5,9]
y = x   #renaming or aliasing
y.pop()
print(x,y)

#copying will affect the duplicates only

y = x.copy()
y.pop()
print(x,y)


#using operators on list

a = [4,2,8,5]
b = [5,3,2]

c = a+b
print(c)

#if we try to add a int we will get error
#c+45 #this will be error
d=c+[45] #this is valid
print(d)

#repetition operator
a = [5,3,2,1]
d = a*2
print(d)

#alphabetical order comparison
x = ['dog','cat','rat']
y = ['Dog','Cat','Rat']

print(x ==y)
print(x != y)



#first element based
x = [30,50,2,3]
y = [25,45,43,1,3]

print(x>y)
print(x<y)


#clear() --to remove all elements of List.
x.clear()
print(x)


#list comprehensions

s = [i*2 for i in y]
print(s)

a ={3,6,8,9,2}




