#string formatting -- passing strings inside of a sentences:

name = input('enter the name')
marks = int(input('enter marks'))
grade = eval(input('enter the grade'))
#method1
print('the student name is %s and the marks he earned %d and the grade he earned %f'%(name,marks,grade))

#method2
print('the student name is {} and the marks he earned {} and the grade he earned {}'.format(name,marks,grade))