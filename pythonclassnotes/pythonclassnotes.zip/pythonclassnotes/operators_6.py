# Operators are used to perform operations on variables and values.
#
# In the example below, we use the + operator to add together two values:

#Arithmetic operators are used with numeric values to perform common mathematical operations:
'''
a=7
b=6

print(a+b)#addition
print(a-b)#subraction
print(a*b)#multiplication
print(a/b)#division
print(a//b)#floor division
print(a**2)#exponential
print(a%b)#remainder


#Assignment operators are used to assign values to variables:

a +=4  #same as x = x+4
print(a)


a -=4  #same as x = x-4
print(a)

a *=4  #same as x = x*4
print(a)

a /=4  #same as x = x/4
print(a)

a //=4  #same as x = x//4
print(a)

a **=2  #same as x = x**4
print(a)

b %=4  #same as x = x%4
print(b)



#Comparison operators are used to compare two values:

a='hello'
b='world'

print(a == b)
print(a != b)
print(a > b)
print(a >= b)
print(a < b)
print(a <= b)


#Logical operators are used to combine conditional statements:

a=-8
b=56
print(a and b)#if both values are true and will return the second value
print(a or b) #if both values are true or will return the first value
print(not a)


# Identical operators are used to compare the objects, not if they are equal, but if they are actually the same object,
# with the same memory location:

a=6
b=6
print(id(a))
print(id(b))
print(a is b)
print(a is not b)

#Membership operators are used to test if a sequence is presented in an object:

a= 'hello world'
print('h' in a)
print('l' not in a)


#ternery operators
a=5
b=4
c = 'smaller' if a<b else 'greater'
print(c)

'''



#Bitwise operators are used to compare (binary) numbers:

#& --it will take the binary version of values and operate them with and operator for each values
'''
 bin(5) --101
 bin(6)-- 110
        -----
          100  
'''

print(5 & 6) #ans 4
print(bin(5))
print(bin(6))
print(int(0b100))#here to check we just passed the binary version out come value 5&6

#    |	OR	--it will take binary versions of given value then perform 'or' operation then it will return result of
#integer version
'''
 bin(5) --101
 bin(6)-- 110
        -----
          111  
'''

print(5 | 6) #ans 7
print(0b111)
#     ^	XOR	--from the binary version given values it will return '1'--if any one value is 1 another is 0
'''
 bin(5) --101
 bin(6)-- 110
        -----
          011  
'''


print(5 ^ 6) #ans 3 ob11
print(int(0b011))

#    ~ 	NOT	Inverts all the bits

'''

 bin(6)--(-( 110+1))
        -----
          -111  #to convert into integer version then add '-' operators to that value
'''

print(~6) #ans -7


#    <<	right shift operator --shifts (or) moves of the number to the right and fills 0 in the void
'''
bin(10) ==0000 1010
#if we move the data to the rightt for 1 space result will be =(0000 0101)
10>>1 =   0000 0101
ex:2
bin(8) ==0000 1000 #doing right shift with 1 bit like --8>>1
        =0000 0100
 
'''


print(bin(8))
print(int(0b100))

print(8>>1) #ans --4 ob10
#000101

# left shift operator --shifts or moves bits of the number to the left then it will fills the void with 0
'''
ex:2
bin(8) ==0000 1000 #doing left shift with 1 bit like --8<<1
        =0001 0000

'''

print(int(0b10000))

print(8<<1) #ans  16
#110100
