#one function which is taking another function as a parameter that function we used to call as a decorator
#without touching the original function if we need add some more attributes we can use decorators

'''
def decorating(a):
    def inner():
        print('this is the extra added line')
        a()
    return   inner



def normal():
    print('this is the normal function')

obj = decorating(normal)
obj()
'''

#@ --method used to provide the propertiess from the decorator to the orgin function

def zerofinder(func):
    def inner(a,b):
        if b == 0:
            print('if we use zero in denominator we will get zerodivision error')
            return
        return func(a,b)
    return inner


@zerofinder
def divide(a,b):
    print(a/b)

divide(6,2)
divide(5,0)