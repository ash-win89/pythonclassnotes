#inheritence --allows us to define a class that inherits all the methods and properties from another class

#sinngleinheritence: -- there can one to one relationship only one parent one child method
'''
class employe:

    def __init__(self,fname,lname):
        self.fname = fname
        self.lname = lname

    def fullname(self):
        print('name of the employe',self.fname+self.lname)

class person(employe):
    pass
    def __init__(self,fname,lname):
        #initializing through the parent class
       employe.__init__(self,fname,lname)
       #super().__init__(fname,lname)
       self.experience = 5


    def welcome(self):
         print('welcome mr',self.fname+self.lname)
x= person('robert','pattinson')
#print(x.fname)
x.fullname()
print(x.experience)
x.welcome()

#multipleinheritence-- many to one --ther can be multiple parents one child

class first:
    def no(self):
        print('this is first class')

class second:

    def no(self):
        print('this is second class')

class third(first,second):
    #instead using object to call every inherited class method we can do at once using define a method
    #in that method we can call all the class by passing self keyword
    def no(self):
        print('this is third class')
        first.no(self)
        second.no(self)


t = third()
t.no()

#multilevel or hybrid inheritence -- many to many --there can be multiple childs and multiple classes
#a class can be derived from more than one parent or base classes
'''
class first:
    def no(self):
        print('this is first class')

class second:

    def no(self):
        print('this is second class')

class third(first,second):
    def no(self):
        print('this is third class')

class fourth(third):
    def no(self):
        print('display all the values from the multilevel inhertence clases')
        first.no(self)
        second.no(self)
        third.no(self)
        print('this is fourth class')

f= fourth()
f.no()
