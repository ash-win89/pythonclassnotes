#
# import numpy as np
#
#
#
# d = np.array([3,2,6,8])
# print(type(d))
# print(np.__version__)
#
#
# #2dimensional
#
# dime2 = np.array([[3,5,2],[6,9,2]])
# print(dime2)
#
# arr = np.array([3,8,6,4], ndmin=4)
# print(arr.astype(str))
#
# print(dime2.shape)
#
#
from scipy.spatial import Delaunay
import numpy_42 as np
import matplotlib.pyplot as plt

# print(constants.liter)
# print(constants.pi)
# print(dir(constants))
#
#data visualization

points = np.array([
    [2,4],
    [3,4],
    [3,0],
    [2,2],
    [4,1]

])

simplices= Delaunay(points).simplices

plt.triplot(points[:,0],
            points[:,1],simplices
            )
plt.scatter(points[:,0],points[:,1],color= 'r')

plt.show()