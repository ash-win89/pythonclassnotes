#module -- a file with .py extension having some functions that we need to use in our program we can import and use it
# from  func_18 import hello,add
# hello()
# add(89)

# import func_18
# func_18.add(45)

from func_18 import add as a
a(78)