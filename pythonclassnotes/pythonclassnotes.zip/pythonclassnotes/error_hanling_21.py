#try -- try block used to put our suspicious code inside of it and try block will return result when the code runs properly
#except -- when the try block code throws error except will execute

'''
#basic
try:#where we can test our code
    x =5/6
    print(x)

except:#let us handle the error
    print('something went wrong')


#hanling different errors

try:
    a=4
    b = 3
    x = a/b
    print(x)
except TypeError:
    print('you are trying to add two different data types')
except ZeroDivisionError:
    print('code that you have written having Zerodivisionerror')
except:
    print('invalid syntax')



#else-- case will execute when the try block found no errors :

#finally -- this block will execute always  whether the program raises error or not it will never care about that
try:
    a = 4
    b = 8
    x = a / b
    print(x)
except TypeError:
    print('you are trying to add two different data types')
except:
    print('code that you have written having error')

else:
    print('there is no errors program succeeded')

finally:
    print('end of the error handling')

'''

class Error(Exception):
    pass

class ValueSmallError(Error):
    pass

class ValueBigError(Error):
    pass

number = 10

while True:

    try:
        gues_num = int(input('enter you guess'))
        if gues_num < number:
            raise ValueSmallError
        elif gues_num > number:
            raise ValueBigError
        break
    except ValueSmallError:
        print('guessed number too small')
    except ValueBigError:
        print('guessed value too big')
print('the guessed number matched you won')


