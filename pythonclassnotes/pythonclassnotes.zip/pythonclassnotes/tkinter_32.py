'''
import tkinter

#creating window
window = tkinter.Tk()
window.title('first title')
label = tkinter.Label(window, text = 'hello world').pack()
window.mainloop()


 #using '*' will import every methods and properties in that library
from tkinter import *
from tkinter import ttk

window = Tk()
window.title('function')
label = Label(window, text = 'hello world', font=('Arial Bold',40)).pack()
window.geometry('400x300')


def clincked():
    print('button clicked')

bt = ttk.Button(window, text='click here', command=clincked)
bt.pack(side='top')
window.mainloop()


##combobox :
from tkinter import *
from tkinter import ttk

window = Tk()
window.title('Combobox')
window.geometry('300x300')

ttk.Label(window, text='giving front and background color',background='red', foreground='white',
          font=('Times New Roman',10)).grid(row=0, column=1)


n = StringVar()
choosen = ttk.Combobox(window, width=34, textvariable=n)

choosen['values'] = (
                    'January',
                    'feb',
                    'march',
                    'april',
                    'may',
                    'june',
                    'july',
                    'august',
                    'sept',
                    'nov',
                    'oct',
                    'dec'
                        )

choosen.grid(column=1, row=5)
choosen.current(6)#default value
window.mainloop()


from tkinter import *

window = Tk()
window.geometry('500x300')

label = Label(window, text = 'artificial intelligence', font ='50')
label.pack()

cbutton1 = IntVar()
cbutton2 = IntVar()
cbutton3 = IntVar()

Button1 = Checkbutton(window, text='python',variable=cbutton1,onvalue=1, offvalue=0,height=2, width=10)
Button2 = Checkbutton(window, text='javascript',variable=cbutton2,onvalue=1, offvalue=0,height=2, width=10)
Button3 = Checkbutton(window, text='java',variable=cbutton3,onvalue=1, offvalue=0,height=2, width=10)

Button1.pack()
Button2.pack()
Button3.pack()
mainloop()



from  tkinter import *

window = Tk()

def sayhi():
    print('say hello to everyone')

menubar = Menu(window)
menubar.add_command(label='hi',command=sayhi)
menubar.add_command(label='exit',command=window.quit)

#display as menubar
window.config(menu=menubar)
window.mainloop()


from tkinter import *

window = Tk()
menubar = Menu(window)
file = Menu(menubar, tearoff=0)

file.add_command(label='new')
file.add_command(label='open')
file.add_command(label='save')
file.add_command(label='save as')
file.add_command(label='close')
file.add_command(label='settings')
file.add_separator()
file.add_command(label='find propertties')

menubar.add_cascade(label='FILES',menu=file)

edit = Menu(menubar, tearoff=0)

edit.add_command(label='cut')
edit.add_command(label='copy')
edit.add_command(label='paste')
edit.add_command(label='delete')
edit.add_command(label='remove')
edit.add_command(label='join')
edit.add_separator()
edit.add_command(label='transpose')

menubar.add_cascade(label='Edit',menu=edit)
Help = Menu(menubar, tearoff=0)

Help.add_command(label='contact us')
Help.add_command(label='about')
menubar.add_cascade(label='help',menu=Help)
window.config(menu=menubar)
window.mainloop()

#spin box
from tkinter import *

window = Tk()
window.geometry('500x500')
window.title('spinbox')
current = StringVar(value=0)
spin = Spinbox(window,from_=0,to=15,textvariable=current,wrap=True)
spin.pack()
window.mainloop()

#simpler spin box:
from tkinter import *
window = Tk()
s =Spinbox(window,from_=0, to = 30)
s.pack()
window.mainloop()'''
#scroll box:

from tkinter import *

window = Tk()
window.geometry('200x200')

scroll = Label(window, text='this is about scroll bar message', font='50')
scroll.pack()

scroll_bar = Scrollbar(window)
scroll_bar.pack(side=RIGHT,fill=Y)
mylist = Listbox(window, yscrollcommand=scroll_bar.set)
for i in range(100):
    mylist.insert(END, "this is the line number"+ str(i))

mylist.pack(side=LEFT, fill=BOTH)
scroll_bar.config(command=mylist.yview)
window.mainloop()