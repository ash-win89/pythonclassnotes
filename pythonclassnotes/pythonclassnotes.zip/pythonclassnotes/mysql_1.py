#assertions -- used to debug the particular line

def square(x):
    return x*x

assert square(4) == 16
print(square(7))
