#regular expression --special sequence of characters which helps us to find or match in a sentence

#starts with finder:

import re
'''
str = 'the highest falls in the world is nayagara'
x = re.findall('^in',str)
print(x)

#finding the boundary characters using []

str = 'the highest falls in the world is nayagara'

x= re.findall('[a-m]',str)
print(x)

str = 'the highest falls in the world is nayagara'
x =re.findall('nayagara$',str)
print(x)


str = 'the tall and small and its fall'
x= re.findall('anx*',str)
print(x)

#the srting contains 'a' that followed two l's:

str = 'the talll and small and its fall so its al'
x= re.findall('al{3}',str)
print(x)

#finding the either condition
str = 'the talll and small and its fall so its al'
x= re.findall('talll|small',str)

print(x)

#try to find a particular word in our string

str = 'the talll and small and its fall so its al'
x= re.findall('fall',str)
print(x)

#search() --used to search a string for a match -- used find the first occurance


str = 'the talll and small and its fall so its al'
x= re.search('\s',str)
print('the white space available in the position no',x.start())


str = 'the talll and small and its fall so its al'
x= re.search('fall',str)
print(x)

#we want to break our sentence based on some character use split()
str = 'the talll and small and its fall so its al'
x= re.split('\s',str)
print(x)

#trying to replace one value instead another

str = 'the talll and small and its fall so its al'
x= re.sub('\s','_',str)
print(x)

#filtering integers in a string

str = 'the 1 st thing we have to wake up 5 o clock on 23 rd'
x = re.findall('[0-9]',str)
print(x)


#filtering special char in a string

str = 'the $ st thing@ we have to wake% up 5$ o @clock on 23 rd'
x = re.findall('[@,$]',str)
print(x)
#group() --want to find the similar word starts with particular character

str = 'the morning sunlight too bright'
x = re.search(r'\bs\w+', str)
print(x.group())'''

#find the  starting position and ending position of a word starts with particular character

str = 'the morning sunlight too bright'
x = re.search(r'\bs\w+', str)
print(x.span())