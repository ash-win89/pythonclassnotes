

#inner class -- a class defined in another class is known inner class or else we can call it as a nested class
class outer:

    def __init__(self):
        print('this message comes from outer class')

    def dummy(self):
        print('this message comes from outer class method')
    class inner:
        def __init__(self):
            print('this message comes from inner class')

        def hello(self):
            print('hello world')

a=outer()
b= a.inner()
b.hello()
a.dummy()