#data types python has 7 types of data

#1. integer family has 4 types -- int, bin,oct, hex
#int--normal whole numbers we used to call them as integers

a =89765

#0s and 1s we used to call them as binary numbers to declare a binary numbers in python use '0b' or '0B'

binary = 0b01001

#0 to 7 numbers are know octal numbers to declare them use '0o' or '0O' in python--IUPAC numeric form -octa stands for =8

octal = 0o7423

#0 to 9 and a to f is know as hexadecimal numbers to declare them use '0x' or '0X'-in IUPAC --16 of hexa

hexa = 0xab952

#2.string -- in python anything that comes under the single or double or triple quotations that known as string
#string is an array of values
b = 'hello world'
c = '569821' #also a string

#3. bool-- True(1), False(0) mentioning true or false called boolean except 0 or nothing('') everythin is true

e= True
f = False

#4.complex -- a real part with imaginary part called complex to declare imaginary part use 'j' in python

g = 4+7j

#None data types are there

h = None

#float
i = 45.348923

print(a,b,c,e,f,g,h,i,binary,octal,hexa)