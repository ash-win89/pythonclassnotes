#build in functions --print,for,if
#user defined functions -- types function,parmeter,arbitrarys, kwagrs,default,keywords,local, global

#it is a reusable code, and it will only executes when its being called while calling it will return the data
#def-- we have to use 'def' keyword to define a function in python
#1.normal
#while defining a function if we pass any data - its known as parameters
#while calling a function if we pass any data --its known as arguments

def hello():
    print('say hello to everyone!!')

# hello()
# hello()

#parameters-- we can pass datas using parameters inside of a function assign variables in the function is parameters
#parameters-- while defining a function giving variable names consider as parameters
#arguments -- the datas the we are assigning with parameters while calliing the function that is arguments
#parameters are acts like a variables to the function and arguments are the values which assign to the variables
def add(x):
    print('the value inserted is',x,'addion with 5',x+5)

# add(6)
# add(5)
# add(55)
# add(34)
'''
def sub(x,y):
    print(x)

sub(4556,566)
#sub(56)

#arbitrary functions-- while calling a function we are not sure how many arguments that being passed inside of our
#function we have to add '*' before the parameter that function is a arbitrary function it will convert the parmeter as a sequence
#so that parameter will act as a sequence and it will store all datas

def channels(*name):
    print('the name of channel position is',name[1])
    #print(name)

channels('e','star','zee','k','sun','maa')

#keyword arguments--we can pass arguments with key=value format

def hero(darkknight,thor,superman):
    print('the hero name of  movie superman',superman)

hero(darkknight='chritianbale',thor='chris hemsworth',superman='henry cavil')





#kwargs functions-- it store the values like a dictionary we can access those values based on keys:

def dictfunc(**a):
    print('the second element of the passed values',a['batman'])

dictfunc(thor='marvel',batman = 'dc', f7= 'wb')

#default parameter-- a function which has it own value if user passes any values it will override the default
#if user passes nothing it will return the default value

def city(cap = 'newyork'):
    print('the capital of united states',cap)

city('los angeles')
city()
city('san francisco')

#passing a list as an argument:

def listcall(a):
    for i in a:
        print(i)

l1 = [3,6,9,1,3]
listcall(l1)

#pass--if we dont have anything to define we can use pass keyword inside of a function.it will return nothing
def nothing():
    pass


#recusive funtion -- a function which is calling itself. it is a recursive function

def fact(x):
    if x==1:
        return 1
    else:
        return (x*fact(x-1))
print(fact(5))

#scope of  a fucntion
#local variable function -- a variable that belongs to a particular which is we cant call outside of the function
#that variable called local variable

def lf():
    x=54    # this variable declared as local
    print(x)

lf()
#print(x)

#global variable function-- a variable which can callable even inside and outside of a function that variable known
#as global variable

x=98 #this variable declared as global
def gf():
    print(x)

print(x)
gf()

#to convert a local variable into a global variable use 'global'

def cgf():
    global y
    y =89
    print(y)


cgf()
print(y)

#naming variable --global,local varibles will not override each other
x=45

def call():
    x=34
    print(x)

print(x)
call()


#function documentation:

def doc():
   #   '''
   # a fucntion which is a short way
   #  to execute an operation multiple
   #  times by just calling it name
   #
   #  '''
   #   print('hello')
    #this single line comment will not execute


#print(doc.__doc__)
#help(doc)



