
#conditional statements-- decision making statements in programming language used to control the direction of the
#flow of program execution

#if case-- will print the result when the condition is true if condition fails it will return nothing
#or--if a certain condition is true then the block of code will execute else it will not return anything
#else--whenever if case will get fails that time else automatically will execute
a = 0
#here even except '0' or '' or False --what ever value there it will considered as True value
if a:
     print('a is a true value')# this line comes under the if block
     #this is where if block ends if we write anythin in margin
else:
     print('a is not a true value')

#indentation --the spaces what we are giving in starting point of lines code, python uses indention to identify
#a block of code


#nested -if--an if statement that is the target of another if statement or nested if statements means
#if statement inside another if statement


#elif --a program can decide multiple options or checking true with multiple conditions or multiple possibilities
ticket_price = 800
trasportation = ['bus','train','ship','flight']

if  ticket_price<500:
    if trasportation[0] == 'bus':
        print('we have a bus ticket')

elif ticket_price <1000:
    if trasportation[1] == "train":
        print('we have a train ticket')

elif ticket_price<1500:
    if trasportation[2] == 'ship':
        print('we have ship ticket')
elif ticket_price<50000:
    if trasportation[3] == 'flight':
        print('we have a flight ticket')
else:
    print('invalid price')

