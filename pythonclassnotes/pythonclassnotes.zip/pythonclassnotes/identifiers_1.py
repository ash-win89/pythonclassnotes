#printing statement

print('hello world')

#identifiers --way of giving names to the variable for different entities such as constants, variables, function
#identifiers used to define variables --rules that we need to follow
#rule --1-- dont use any constant values infront of a variable or we should pass any constant values in the first
#place of a variable name
#1a =55 #wrong

a = 'apple'
a2b = 78 # in the middle or end we can use identifiers
a1 = 67
print(a,a2b,a1)

#rule --2-- dont use special characters even middle or first or end

name = 'hello'  # wrong

#rule --3 -- keywords should be used as a variable or-- reserved words already occupied with some operation

#and = 45


#to define or to intimate any variable as a private values we have to use underscore single underscore
#means private double underscore means strictly private

_private = 'this is the private key'
#
__sPrivate = 'this is strictly private key'

#to define a constant value for a variable we have to use uppercases while defining a variable

APPLE =45
print(_private,APPLE)

