#date time:
'''
import datetime

#print local machine time
x = datetime.datetime.now()
print(x)

#to print year we have to use 'year' keyword
print(x.year)
print(x.month)
print(x.day)
print(x.second)
print(x.hour)
print(x.microsecond)
print(x.minute)


#to get string format use keyword 'strftime'
print(x.strftime('%A'))
print(x.strftime('%B'))
print(x.strftime('%a'))

#to get to know the day of a particular year

y = datetime.datetime(1997,8,3)
print(y.strftime('%A'))

import time

#time library has 'sleep()' which will freeze the program till the mentioned timing

print('this message will come immediately')

time.sleep(3)
print('this message will pring after 3 secs')

#creating digital clock using time library:
'''
import time

while True:
    localtime = time.localtime()
    result = time.strftime("%I:%M:%S %p",localtime)
    print(result)
    time.sleep(1)
