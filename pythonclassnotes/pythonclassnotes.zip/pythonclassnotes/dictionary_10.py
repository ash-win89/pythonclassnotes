#dictionary comprehensions --If we want to represent a group of objects as key-value pairs then we should go for
#Dictionary.

#to create empty dictionary

a = {}
print(type(a))
b = dict()

#adding elements to a dictionary

a[1] = 'apple'
a[2] = 'cherry'
a[3] = 'kiwi'
a[999] = 'orange'

print(a)

#to access a value from a dictionary
print(a[3])

del a[2]
print(a)

a.clear()  # used to remove all elements
print(a)

del a # to delete the entire dictionary
#print(a)

#to create a empty dictionary
a = dict()
b = {'a':3,'b':7,'c':9}

print(len(b))  #used to find the number of items

#get()-- used to get value associated with that key

print(b.get('c'))

#using pop in dictionary use the key as well
b.pop('b')

print(b)

#popitem used to remove the last item of the dictionary
b.popitem()

print(b)

b={'a':5,'b':56,'c':34}
#keys():--It returns all keys associated eith dictionary

print(b.keys())
#values() --It returns all values associated with the dictionary

print(b.values())

#items() --It returns list of tuples representing key-value pairs.
print(b.items())


#copy():--To create exactly duplicate dictionary(cloned copy)

b = {'a':3,'b':7,'c':9}

c = b.copy()
c.popitem()
print(b,c) # b will remain same for copy

#aliasing -renaming

d = b
d.pop('a')
print(d,b)


#comprehend a dictionary

a = {'apple':5,'kiwi':45,'orange':46}
print(a)

s = [a[x] for x in a]
print(s)

