#any -- if you are giving sequence values if any one of them is true 'any'--will return true

l = [0,0,1,0]
print(any(l))
print(all(l))

print(any([True,False,False,False]))


#all --every value should be true then it will return true

print(all([True,False,False,False]))
print(all([True,True,True]))