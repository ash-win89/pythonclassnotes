#polymorphism will let us define  methods  with same name even for parent can also have even can have same of a method
'''

#if we have multiple class methods with same name the parentclass methods will be overloaded by the child class methods
class Bird:

    def species(self):
        print('there is different types of birds are there but every birds have wings')

    def flight(self):
        print('some of them can fly some of them can walk')

class eagle(Bird):

    def flight(self):
        print('eagle can fly on top of the sky')

class ostrich(Bird):
    def flight(self):
        print('ostriches cannot fly but they can run')

b =Bird()
e= eagle()
o = ostrich()

b.species()
b.flight()

e.species()
e.flight()

o.species()
o.flight()


#operator overloading -- we can use same operator for multiple purpose:

class Book:

    def __init__(self,pages):
        self.pages = pages

    def __add__(self, other):
        return self.pages+other.pages



b1 = Book(500)
b2 = Book(300)
print(b1+b2)


#method overloading -- last method will override previous methods inside of  class
#alternatively if we do have multiple methods with same name inside of a single class that also will get overload
#the final method will overload the previous methods
class Test:

    def call(self,a):
        print('this method has one parameter')

    def call(self,a,b):
        print('this method has two parameters')

    def call(self):
        print('this method has no arguments')

t =Test()
t.call()


class Test:

    def __init__(self):
        print('this construct have no parameters')


    def __init__(self,a):
        print('this construct have one parameters')


    def __init__(self,a,b):
        print('this construct have two parameters')

Test(3,6)


#one more example for method overloading
class courses:

    def __init__(self):
        print('this is about learnig internship')

    def course(self):
        print('the course name is javascript')

class intern(courses):
    def  course(self):
        print('the course name is python')


i = intern()
i.course()

#method overriding
class add:

    def sum(self,a=None,b=None,c=None):
        if a!=None and b!=None and c!=None:
            print('sum of the given 3 numbers is ==', a+b+c)

        elif a!=None and b!=None:
            print('sum of the given 2 numbers ==', a+b)

        else:
            print('the passed number is ==',a)
a =add()
a.sum(2)

'''
class Parent:
    def __init__(self):
        print('this message is coming from parent class')

class Child(Parent):
    def __init__(self):
        print('this message is coming child class')


Child()
